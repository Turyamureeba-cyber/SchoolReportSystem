from flask import Blueprint, render_template, request, redirect, url_for
from .models import *
from . import db

main = Blueprint('main', __name__)

@main.route('/')
def home():
    return render_template('dashboard.html')

@main.route('/students')
def students():
    student_list = Student.query.all()
    return render_template('student_list.html', students=student_list)
